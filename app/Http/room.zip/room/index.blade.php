@extends('layouts.app')
@section('content')
@if ($message = Session::get('message'))
 <div class="alert alert-success martop-sm">
 <p>{{ $message }}</p>
 </div>
@endif
            <div>
                <div class="form-group">
                    <input type="text" name="nama" value="{{Session::get('namaPemesan')}}" class="form-control col-md-8">
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <input type="date" name="masuk" value="{{Session::get('masuk')}}" class="form-control">
                    </div>
                    <div class="form-group col-md-6">
                        <input type="date" name="keluar" value="{{Session::get('keluar')}}" class="form-control col-md-6">
                    </div>
                </div>
            </div>
<h1 class="bg-secondary text-white text-center">Daftar Kamar</h1>
<div class="card-columns">
            @foreach($rooms as $r)
            @php
            if(Session::has('cart')){
                $cart=Session::get('cart');
                if (array_key_exists($r->id,$cart->items)){
                    continue;
                }
            }
            $foto='upload/img/'.$r->image;
            @endphp
            <div class="card p-0">
                <a class="text-dark" href="{{route('room.show',$r->id)}}">
                <img src="{{asset($foto)}}" class="card-img-top" alt="{{$r->image}}">
                <div class="card-body">
                <h5 class="card-title text-white badge badge-secondary">No {{$r->id}}</h5>
                    <h5 class="card-title text-white badge badge-secondary">Rp {{$r->price}}</h5>
                    <table class="table table-sm bg-white mb-2 ">
                        <tbody>
                            <tr>
                                <td >Name</td>
                                <td>: {{$r->name}}</td>
                            </tr>
                            <tr>
                                <td>Owner</td>
                                <td>: {{$r->getAdmin->name}}</td>
                            </tr>
                            <tr>
                                <td>bed</td>
                                <td>: {{$r->bed}}</td>
                            </tr>
                            <tr>
                                <td>quota</td>
                                <td>: {{$r->quota}}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                </a>
            </div>
            @endforeach
@endsection