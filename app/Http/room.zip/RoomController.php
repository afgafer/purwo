<?php

namespace App\Http\Controllers;

use App\models\Room;
use Illuminate\Http\Request;
use File;

class RoomController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rooms=Room::orderBy('id','ASC')->get();
        return view('room.index', compact('rooms'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('room.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $max= Room::max('id');
        if($max==null){
            $max=0;
        }
        $id=++$max;

        
        $room=new Room();
        $room->id=$id;
        $room->name=$request->name;
        $image=$request->image;
        if($image){
            $nameI = 'room_'.$id.'.'.$image->getClientOriginalExtension();    
            $image->move('upload/img',$nameI);
            $room->image=$nameI;
        }
        $room->quota=$request->quota;
        $room->price=$request->price;
        $room->bed=$request->bed;
        $room->desc=$request->desc;
        $room->admins_id=auth()->user()->id;
        $room->save();
        $msg="The rooom ".$room->name." has been stored";

        return redirect()->route('room.index')
                ->with('message',$msg);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\models\Kamar  $room
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $room= Room::findOrFail($id);
        return view('room.show', compact('room'));
        //return $room->id;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\models\Kamar  $room
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $room= Room::findOrFail($id);
        return view('room.edit', compact('room'));
        //return $room->id;
    }   

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\models\Kamar  $room
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $room= Room::findOrFail($id);
        $room->name=$request->name;
        $image=$request->image;
        if($image){
            $oldI='upload/img/'.$room->image;
            File::delete($oldI);
            $nameI = 'room_'.$id.'.'.$image->getClientOriginalExtension();    
            $image->move('upload/img',$nameI);
            $room->image=$nameI;
        }
        $room->quota=$request->quota;
        $room->price=$request->price;
        $room->bed=$request->bed;
        $room->desc=$request->desc;
        $room->admins_id=auth()->user()->id;
        $room->save();
        $msg="The room ".$room->name." has been updated ";

        return redirect()->route('room.index')
                ->with('message',$msg);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\models\Kamar  $room
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {   
        $room= Room::findOrFail($id);
        if(Room::destroy($id)){
            $oldI='upload/img/'.$room->image;
            File::delete($oldI);
            $msg="The room ".$room->name." has deleted";
        }else{
            $msg="The room ".$room->name." hasn't deleted";
        }
        return redirect()->route('room.index')
                ->with('message',$msg);
    }
}
